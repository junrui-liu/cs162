from typing import Any
from frontend.lang import *


def subst(sigma: dict[Var, Any], node: SrcMap | Expr | Binder):
    if len(sigma) == 0:
        return node
    match node:
        case SrcMap(node, src):
            return SrcMap(subst(sigma, node), src)
        case Binder(var, scope):
            return Binder(var, subst({k: v for k, v in sigma.items() if k != var}, scope))
        case Expr():
            e = node
            match e:
                case Nat() | Bool():
                    return e
                case Binop(op, e1, e2):
                    pass
                    # your code here
                case Ite(cond, thn, els):
                    pass
                    # your code here
                case Abbrev():
                    return e
                case Var(_):
                    pass
                    # your code here
                case Lambda(b):
                    pass
                    # your code here
                case App(e1, e2):
                    pass
                    # your code here
                case Let(e, b):
                    pass
                    # your code here
                case Pack(es):
                    pass
                    # your code here
                case Unpack(e1, xs, e2):
                    pass
                    # your code here
                case Annot(e, t):
                    return Annot(subst(sigma, e), t)
        case _:
            raise ValueError(f"subst: Unexpected node type: {type(node)}")

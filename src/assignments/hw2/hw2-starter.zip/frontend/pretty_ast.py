from PrettyPrint import PrettyPrintTree
from .lang import *
from colored import Fore, Back, Style
from typing import Optional, Any


DEFAULT_BACK = '\x1b[100m'


@dataclass
class Atom:
    s: str


ellipsis = Atom('..')


@dataclass
class LabelNode[T]:
    label: str
    content: T


@dataclass
class Result:
    value: Any
    children: list[Any]
    label: Optional[Any] = None


def style_value(fore=Fore.white, back=DEFAULT_BACK):
    def decorator(func):
        def wrapper(*args, **kwargs):
            result: Result = func(*args, **kwargs)
            result.value = f'{fore}{back}{result.value}{DEFAULT_BACK}'
            return result
        return wrapper
    return decorator


def get(node):
    match node:
        case Atom(s):
            return Result(s, [])
        case LabelNode(l, x):
            match get(x):
                case Result(v, cs, _):
                    return Result(v, cs, l)

        case Binder(x, s):
            def sty(x): return f'{Fore.black}{Back.white} {x} {Style.reset}'
            vars = [sty(x.name)]
            while isinstance(s, Binder):
                vars.append(sty(s.var.name))
                s = s.scope
            return get(LabelNode('─'.join(vars), s))

        case Expr():

            e = node
            match e:
                case Nat(n):
                    return Result(wl.pformat(e), [])
                case Binop(op, e1, e2):
                    return Result(wl.pformat(op), [e1, e2])
                case Bool(b):
                    return Result(wl.pformat(e), [])
                case Ite(cond, thn, els):
                    return Result('ite', [cond, thn, els])
                case Var(x):
                    return Result(x, [])
                case Abbrev(x):
                    return Result(x, [])
                case Lambda(b):
                    return Result('λ', [b])
                case App(l, r):
                    # spine = [r]
                    # while isinstance(l, App):
                    #     spine = [l.r] + spine
                    #     l = l.l
                    # spine = [l] + spine
                    # return Result('$', spine)
                    return Result('$', [l, r])
                case Let(l, r):
                    return Result('let', [l, r])
                case _:
                    print(f'Unhandled expr: {type(e)}')
                    exit()
        case _:
            return Result(node, [])


def get_children(x):
    return get(x).children


def get_val(x):
    return get(x).value


def get_label(x):
    return get(x).label


pp_ast = PrettyPrintTree(get_children, get_val, get_label,
                         orientation=PrettyPrintTree.Vertical,
                         return_instead_of_print=True)

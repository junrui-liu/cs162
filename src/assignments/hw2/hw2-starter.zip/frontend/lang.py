import wadler_lindig as wl
from wadler_lindig import TextDoc as d, BreakDoc as br
from dataclasses import dataclass


# You can always ignore __repr__ and __pdoc__ functions
# They're just for pretty-printing purposes.


@dataclass(frozen=True)
class Expr:

    def __repr__(self):
        return wl.pformat(self)


@dataclass(frozen=True)
class Nat(Expr):
    n: int

    def __pdoc__(self, **kwargs):
        return d(str(self.n))


def nat(n):
    return Nat(n)


@dataclass(frozen=True)
class NatOp:
    def __repr__(self):
        return wl.pformat(self)


@dataclass(frozen=True)
class Add(NatOp):
    def __pdoc__(self, **kwargs):
        return d("+")


@dataclass(frozen=True)
class Sub(NatOp):
    def __pdoc__(self, **kwargs):
        return d("-")


@dataclass(frozen=True)
class Mul(NatOp):
    def __pdoc__(self, **kwargs):
        return d("*")


@dataclass(frozen=True)
class Eq(NatOp):
    def __pdoc__(self, **kwargs):
        return d("==")


@dataclass(frozen=True)
class Binop(Expr):
    op: NatOp
    e1: Expr
    e2: Expr

    def __pdoc__(self, **kwargs):
        return d("(") + wl.pdoc(self.e1) + br(" ") + wl.pdoc(self.op) + d(" ") + wl.pdoc(self.e2) + d(")")


def add(e1, e2):
    return Binop(Add(), e1, e2)


def sub(e1, e2):
    return Binop(Sub(), e1, e2)


def mul(e1, e2):
    return Binop(Mul(), e1, e2)


def eq(e1, e2):
    return Binop(Eq(), e1, e2)


@dataclass(frozen=True)
class Bool(Expr):
    b: bool

    def __pdoc__(self, **kwargs):
        return d(str(self.b))


def tt():
    return Bool(True)


def ff():
    return Bool(False)


@dataclass(frozen=True)
class Ite(Expr):
    "Represent if-then-else"
    cond: Expr
    thn: Expr
    els: Expr

    def __pdoc__(self, **kwargs):
        return ((d("if ") + wl.pdoc(self.cond))
                + br(" ")
                + (d("then ") + wl.pdoc(self.thn))
                + br(" ")
                + (d("else ") + wl.pdoc(self.els))).group()


def ite(cond, thn, els):
    return Ite(cond, thn, els)


@dataclass(frozen=True)
class Var(Expr):
    name: str

    def __pdoc__(self, **kwargs):
        return d(self.name)


def var(name):
    return Var(name)


@dataclass(frozen=True)
class Abbrev(Expr):
    """Global variable"""
    name: str

    def __pdoc__(self, **kwargs):
        return d(self.name)


def abbrev(name):
    return Abbrev(name)


@dataclass(frozen=True)
class Binder[T]:
    """Binder node

    The syntax Binder[T] means that Binder is a template class where T is a typename, so it'd be like this in C++
    template<typename T>
    class Binder { ... }

    In this HW, you can assume that scope: T is always scope: Expr.

    I made the Binder class generic over the scope type 
    since future HW will allow different types for scope"""

    var: Var
    scope: T

    def __repr__(self):
        return wl.pformat(self)

    def __pdoc__(self, **kwargs):
        return wl.pdoc(self.var) + d(".") + br("") + wl.pdoc(self.scope)


def binder(var, scope):
    return Binder(var, scope)


@dataclass(frozen=True)
class Lambda(Expr):
    # this syntax means b is a Binder where type T (the type of scope) is instantiated with Expr
    b: Binder[Expr]

    def __pdoc__(self, **kwargs):
        return wl.NestDoc(
            d("\\") + wl.pdoc(self.b.var) + d(".") +
            br(" ") + wl.pdoc(self.b.scope),
            kwargs["indent"])


def lam(b):
    return Lambda(b)


@dataclass(frozen=True)
class App(Expr):
    e1: Expr
    e2: Expr

    def __pdoc__(self, **kwargs):
        return wl.NestDoc(
            d("(") + wl.pdoc(self.e1) + br(" ") + wl.pdoc(self.e2) + d(")"),
            kwargs["indent"])


def app(e1, e2):
    return App(e1, e2)


@dataclass(frozen=True)
class Let(Expr):
    e: Expr
    # this syntax means b is a Binder where type T (the type of scope) is instantiated with Expr
    b: Binder[Expr]

    def __pdoc__(self, **kwargs):
        return wl.GroupDoc(d("let ") + wl.pdoc(self.b.var) + d(" = ") + wl.pdoc(self.e) + d(" in") + br(" ") + wl.pdoc(self.b.scope))


def let(l, r):
    return Let(l, r)


@dataclass(frozen=True)
class Prog:
    defn: dict[Abbrev, Expr]
    main: Expr

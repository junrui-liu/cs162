import sys
import wadler_lindig as wl
import logging
import lark as lark
from lark import Lark, Transformer, v_args
from . import lang
from .pretty_ast import pp_ast

logger = logging.getLogger(__name__)

_input = None


@v_args(meta=True)
class AstTransformer(Transformer):

    # Terminals

    def LOCAL(self, t):
        return t.value

    def GLOBAL(self, t):
        return t.value

    # Non-terminals

    def prog(self, meta, items):
        *decls, main = items
        defn = {}
        for (sort, k, v) in decls:
            match sort:
                case "defn":
                    defn[k] = v
                case _:
                    raise ValueError(f"Unknown sort {sort}")
        return lang.Prog(defn, main)

    def defn(self, meta, items):
        name, e = items
        name = lang.abbrev(name)
        return ("defn", name, e)

    def main(self, meta, e):
        return e[0]

    def lam(self, meta, items):
        var, body = items
        return lang.lam(lang.binder(lang.var(var), body))

    def let(self, meta, items):
        x, e1, e2 = items
        return lang.let(e1, lang.binder(lang.var(x), e2))

    def app(self, meta, items):
        return lang.app(*items)

    def expr_var(self, meta, x):
        return lang.var(*x)

    def expr_abbrev(self, meta, x):
        return lang.abbrev(*x)

    def paren(self, meta, items):
        return items[0]

    def nat(self, meta, items):
        (n_str, ) = items
        return lang.nat(int(n_str))

    def add(self, meta, items):
        e1, e2 = items
        return lang.add(e1, e2)

    def sub(self, meta, items):
        e1, e2 = items
        return lang.sub(e1, e2)

    def mul(self, meta, items):
        e1, e2 = items
        return lang.mul(e1, e2)

    def eq(self, meta, items):
        e1, e2 = items
        return lang.eq(e1, e2)

    def true(self, meta, items):
        return lang.tt()

    def false(self, meta, items):
        return lang.ff()

    def ite(self, meta, items):
        cond, thn, els = items
        return lang.ite(cond, thn, els)


def handle_errors(e):
    logger.error("I ran into a problem during parsing...\n")
    match e:
        # UnexpectedCharacters is a lexer error, which keeps a copy of input
        # and prints the context by default
        case lark.UnexpectedCharacters():
            pass
        # parser errors don't have a copy of input, so if we want an error context,
        # we have to explicitly construct using the cached input
        case _:
            logger.error(e.get_context(_input))
    logger.error(e)
    # exit()
    return False


parser = Lark.open("grammar.lark", rel_to=__file__,
                   parser='lalr', propagate_positions=True)
transformer = AstTransformer()


def parse_tree(s):
    global _input
    _input = s
    print(s)
    return parser.parse(s, on_error=handle_errors)


def parse(s):
    return transformer.transform(parse_tree(s))


def parse_stdin():
    return parse(sys.stdin.read())


def parse_string(s):
    return parse(s)


def parse_file(path):
    s = None
    with open(path) as f:
        s = f.read()
    if s is not None:
        return parse(s)
    else:
        raise


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    pt = parse_tree(sys.stdin.read())
    pt.pretty()
    prog: lang.Prog = transformer.transform(pt)
    for line in prog.defn:
        for (x, e) in prog.defn.items():
            print(f"def {x}")
            print("Concrete syntax:")
            print(wl.pformat(e))
            print("AST:")
            print(pp_ast(e))
    print("Main")
    print("Concrete syntax:")
    print(wl.pformat(prog.main))
    print("AST:")
    print(pp_ast(prog.main))

from frontend.lang import *
import frontend.pretty_ast as pretty
from .subst import subst


@dataclass
class Val:
    pass


@dataclass
class VNat(Val):
    n: int


@dataclass
class VBool(Val):
    b: bool


@dataclass
class VLambda(Val):
    b: Binder[Expr]


def val_to_expr(v: Val) -> Expr:
    match v:
        case VNat(n):
            return Nat(n)
        case VBool(b):
            return Bool(b)
        case VLambda(b):
            return Lambda(b)
        case _:
            raise ValueError(f"Not a value: {v}")


def pp_with_conv(conv):
    def f(x):
        return pretty.pp_ast(conv(x))
    return f


pp_val_ast = pp_with_conv(val_to_expr)


class InterpreterError(Exception):
    pass


class UnknownAbbrev(InterpreterError):
    pass


class UnboundVariable(InterpreterError):
    pass


class ApplyingNonFunction(InterpreterError):
    pass


class BinopError(InterpreterError):
    pass


class IteError(InterpreterError):
    pass


class InvalidExpr(InterpreterError):
    pass


@dataclass
class Interpreter:
    prog: Prog

    def run(self):
        return self.eval(self.prog.main)

    def eval(self, e: Expr) -> Val:
        # you can uncomment the following line to print each time an expression is evaluated

        # print(f"eval {wl.pformat(e)}") # this prints e in concrete syntax
        # print(f"eval\n{pretty.pp_ast(e)}") # this prints e as an AST

        match e:
            case Abbrev(x):
                if e in self.prog.defn:
                    return self.eval(self.prog.defn[e])
                else:
                    raise UnknownAbbrev(x)

            case Nat(n):
                pass
                # your code here

            case Binop(op, e1, e2):
                match self.eval(e1), self.eval(e2):
                    case _:
                        pass
                        # your code here

            case Bool(n):
                pass
                # your code here

            case Ite(cond, thn, els):
                pass
                # your code here

            case Var(x):
                pass
                # your code here

            case Lambda(b):
                pass
                # your code here

            case App(e1, e2):
                pass
                # your code here
                # hint: remember to call val_to_expr to convert a Val to an Expr
                # if you need to do a subst

            case Let(e, b):
                pass
                # your code here
                # hint: remember to call val_to_expr to convert a Val to an Expr
                # if you need to do a subst

            case _:
                raise InvalidExpr(e)


if __name__ == '__main__':
    import frontend.parse as parse
    program = parse.parse_stdin()
    e = Interpreter(program)
    print(f"Result: {wl.pformat(e.run())}")

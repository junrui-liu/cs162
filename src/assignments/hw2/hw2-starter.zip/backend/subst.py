from frontend.lang import *


def subst(x: Var, r: Expr, node: Expr | Binder) -> Expr | Binder:
    match node:
        case Binder(y, scope):
            pass
            # your code here
            # this is the binder case
            # hint: remember subst only replaces free references to x
        case Expr():
            e = node
            match e:
                case Nat() | Bool():
                    return e
                case Binop(op, e1, e2):
                    pass
                    # your code here
                case Ite(cond, thn, els):
                    pass
                    # your code here
                case Abbrev():
                    # abbrevations are global variables, so we don't substitute them ever
                    return e
                case Var():
                    pass
                    # your code here
                    # hint: note that x has type Var
                    # you can use `==` to directly compare two Var's
                    # since @dataclass automatically derived an implementation of `==` for us!
                    # the default implementation will compare the names of the two Var's using primitive string equality
                case Lambda(b):
                    pass
                    # your code here
                    # hint: just recurse. let the Binder case handles the binder
                case App(e1, e2):
                    pass
                    # your code here
                case Let(e, b):
                    pass
                    # your code here
                    # hint: just recurse. let the Binder case handles the binder
        case _:
            raise ValueError(f"Unknown node: {node}")

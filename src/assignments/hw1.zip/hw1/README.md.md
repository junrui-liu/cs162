# HW1 🐍
